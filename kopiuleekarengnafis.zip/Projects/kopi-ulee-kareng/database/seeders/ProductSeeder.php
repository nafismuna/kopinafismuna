<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $products = [
            [
                'nama_produk' => 'Kopi Ulee Kareng Original',
                'deskripsi' => 'Kopi khas Aceh dengan aroma kuat.',
                'harga' => 25000,
                'gambar' => 'kopi-kampung.jpg',
            ],
            [
                'nama_produk' => 'Kopi Sanger',
                'deskripsi' => 'Perpaduan kopi dan susu yang lembut.',
                'harga' => 18000,
                'gambar' => 'sanger.jpg',
            ],
            [
                'nama_produk' => 'Kopi Tubruk Aceh',
                'deskripsi' => 'Sajian tradisional dengan rasa pekat.',
                'harga' => 15000,
                'gambar' => 'tubruk.jpg',
            ],
        ];

        foreach ($products as $product) {
            Product::query()->updateOrCreate(
                ['nama_produk' => $product['nama_produk']],
                $product
            );
        }
    }
}