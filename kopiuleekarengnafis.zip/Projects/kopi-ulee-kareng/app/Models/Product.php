<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_produk',
        'deskripsi',
        'harga',
        'gambar',
    ];

    public const GAMBAR_DEFAULT = 'kopi-default.svg';

    /**
     * URL gambar produk. Jika kolom kosong atau file tidak ada di
     * public/images, otomatis memakai gambar cadangan.
     */
    public function getGambarUrlAttribute(): string
    {
        $nama = $this->gambar ? basename($this->gambar) : null;

        if (! $nama || ! is_file(public_path('images/' . $nama))) {
            $nama = self::GAMBAR_DEFAULT;
        }

        return asset('images/' . $nama);
    }

    protected function casts(): array
    {
        return [
            'harga' => 'integer',
        ];
    }
}