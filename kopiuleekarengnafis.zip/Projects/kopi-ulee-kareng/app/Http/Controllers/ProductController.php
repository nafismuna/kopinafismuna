<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\View\View;


class ProductController extends Controller
{
    public function landing(): View
    {
        $products = Product::query()->latest()->get();

        return view('landing', compact('products'));
    }

    public function index(): View
    {
        $products = Product::query()->latest()->get();

        return view('produk.index', compact('products'));
    }

    public function create(): View
    {
        return view('produk.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate(
            [
                'nama_produk' => ['required', 'string', 'max:100'],
                'deskripsi' => ['required', 'string'],
                'harga' => ['required', 'integer', 'min:0'],
               'gambar' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            ],
            $this->validationMessages()
        );

        if ($request->hasFile('gambar')) {
            $validated['gambar'] = $this->simpanGambar($request->file('gambar'));
        } else {
            unset($validated['gambar']);
        }

        Product::query()->create($validated);

        return redirect()
            ->route('produk.index')
            ->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit(Product $produk): View
    {
        return view('produk.edit', compact('produk'));
    }

    public function update(
        Request $request,
        Product $produk
    ): RedirectResponse {
        $validated = $request->validate(
            [
                'nama_produk' => ['required', 'string', 'max:100'],

                'deskripsi' => ['required', 'string'],
                'harga' => ['required', 'integer', 'min:0'],
               'gambar' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            ],
            $this->validationMessages()
        );

        if ($request->hasFile('gambar')) {
            $gambarLama = $produk->gambar;
            $validated['gambar'] = $this->simpanGambar($request->file('gambar'));
            $produk->update($validated);
            $this->hapusGambar($gambarLama);
        } else {
            unset($validated['gambar']);
            $produk->update($validated);
        }

        return redirect()
            ->route('produk.index')
            ->with('success', 'Produk berhasil diperbarui.');
    }

    public function destroy(Product $produk): RedirectResponse
    {
        $gambar = $produk->gambar;
        $produk->delete();
        $this->hapusGambar($gambar);

        return redirect()
            ->route('produk.index')
            ->with('success', 'Produk berhasil dihapus.');
    }

    private function simpanGambar(UploadedFile $file): string
    {
        $folder = public_path('images');

        if (! is_dir($folder)) {
            mkdir($folder, 0755, true);
        }

        $nama = uniqid('produk_') . '.' . $file->extension();
        $file->move($folder, $nama);

        return $nama;
    }

    /**
     * Hapus file gambar hanya jika hasil upload (prefix "produk_"),
     * supaya gambar bawaan seperti sanger.jpg tidak ikut terhapus.
     */
    private function hapusGambar(?string $nama): void
    {
        if ($nama && str_starts_with($nama, 'produk_')) {
            $path = public_path('images/' . basename($nama));

            if (is_file($path)) {
                @unlink($path);
            }
        }
    }

    private function validationMessages(): array
    {
        return [
            'nama_produk.required' => 'Nama produk wajib diisi.',
            'nama_produk.max' => 'Nama maksimal 100 karakter.',
            'deskripsi.required' => 'Deskripsi wajib diisi.',
            'harga.required' => 'Harga wajib diisi.',
            'harga.integer' => 'Harga harus berupa bilangan bulat.',
            'harga.min' => 'Harga tidak boleh negatif.',
            'gambar.max' => 'Ukuran gambar maksimal 2 MB.',
            'gambar.uploaded' => 'Gambar gagal diunggah. Pastikan ukurannya tidak melebihi batas server.',
            'gambar.image' => 'File harus berupa gambar.',
            'gambar.mimes' => 'Format gambar harus JPG, JPEG, PNG, atau WEBP.',
        ];
    }
}

