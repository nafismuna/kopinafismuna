<?php $__env->startSection('title', 'Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>
<main class="admin-page">
    <div class="container admin-container">
        <div class="page-heading">
            <div>
                <span class="eyebrow">Pengelolaan produk</span>
                <h1>Tambah Produk</h1>
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('produk.store')); ?>"
              class="form-card">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('produk._form', ['tombol' => 'Simpan Produk'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/zryconx/Projects/kopi-ulee-kareng/resources/views/produk/create.blade.php ENDPATH**/ ?>