<?php $__env->startSection('title', 'Kelola Produk'); ?>

<?php $__env->startSection('content'); ?>
<main class="admin-page">
    <div class="container admin-container wide">
        <div class="page-heading">
            <div>
                <span class="eyebrow">Dashboard sederhana</span>
                <h1>Kelola Produk</h1>
            </div>
            <div class="heading-actions">
                <a class="btn btn-secondary" href="<?php echo e(route('landing')); ?>">
                    Lihat Landing Page
                </a>
                <a class="btn" href="<?php echo e(route('produk.create')); ?>">
                    Tambah Produk
                </a>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Harga</th>
                        <th>Gambar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <strong><?php echo e($produk->nama_produk); ?></strong>
                                <small><?php echo e($produk->deskripsi); ?></small>
                            </td>
                            <td>
                                Rp<?php echo e(number_format($produk->harga, 0, ',', '.')); ?>

                            </td>
                            <td><?php echo e($produk->gambar ?: 'kopi-default.jpg'); ?></td>
                            <td class="actions">
                                <a class="btn btn-small btn-edit"
                                   href="<?php echo e(route('produk.edit', $produk)); ?>">
                                    Edit
                                </a>
                                <form method="POST"
                                      action="<?php echo e(route('produk.destroy', $produk)); ?>"
                                      onsubmit="return confirm('Hapus produk ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-small btn-danger"
                                            type="submit">
                                        Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="empty-state">
                                Belum ada produk.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>     
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/zryconx/Projects/kopi-ulee-kareng/resources/views/produk/index.blade.php ENDPATH**/ ?>